const whispers = [
  { id: 1, message: 'Hello' },
  { id: 2, message: 'World' }
]
const inventedId = 12345
const existingId = whispers[0].id

export {
  whispers,
  inventedId,
  existingId
}
