module.exports = {
  testEnvironment: 'node',

  transform: {
    '^.+\\.ts$': ['ts-jest', { useESM: true, tsconfig: 'tsconfig.test.json' }]
  },

  extensionsToTreatAsEsm: ['.ts'],

  // keep this for NodeNext-style ".js" specifiers in TS imports
  moduleNameMapper: {
    '^(\\.{1,2}/.*)\\.js$': '$1'
  },

  testMatch: ['**/?(*.)+(spec|test).ts']
}