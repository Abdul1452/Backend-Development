import express from 'express'
import type { Request, Response, NextFunction, ErrorRequestHandler } from 'express'
import { getAll, getById, create, updateById, deleteById } from './store.js'

type IdParams = { id: string }

const app = express()

app.use(express.static('public'))
app.use(express.json())
app.set('view engine', 'ejs')

app.get('/api/v1/whisper', async (req: Request, res: Response) => {
  const whispers = await getAll()
  res.json(whispers)
})

app.get('/api/v1/whisper/:id', async (req: Request<IdParams>, res: Response) => {

  const id = parseInt(req.params.id, 10)
  if (Number.isNaN(id)) {
    return res.sendStatus(400)
  }
  const whisper = await getById(id)
  if (!whisper) {
    return res.sendStatus(404)
  } else {
    return res.json(whisper)
  }
})

app.post('/api/v1/whisper', async (req: Request, res: Response) => {
  // Implement this
})

app.put('/api/v1/whisper/:id', async (req: Request<IdParams>, res: Response) => {
  // Implement this
})

app.delete('/api/v1/whisper/:id', async (req: Request<IdParams>, res: Response) => {
  const id = parseInt(req.params.id, 10)
  if (Number.isNaN(id)) {
    return res.sendStatus(400)
  }
  const whisper = await getById(id)
  if (!whisper) {
    res.sendStatus(404)
  } else {
    await deleteById(id)
    res.sendStatus(204)
  }
})

app.get('/about', async (req: Request, res: Response) => {
  const whispers = await getAll()
  res.render('about', { whispers })
})

app.use((req: Request, res: Response) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'Not Found' })
  }
  res.status(404).send('404 Not Found')
})

const errorHandler: ErrorRequestHandler = (err: any, req: Request, res: Response, next: NextFunction) => {
  console.error(err)
  if (res.headersSent) return next(err)
  if (req.path.startsWith('/api/')) {
    return res.status(500).json({ error: 'Internal Server Error' })
  }
  res.status(500).send('500 Internal Server Error')
}

app.use(errorHandler)

export { app }
