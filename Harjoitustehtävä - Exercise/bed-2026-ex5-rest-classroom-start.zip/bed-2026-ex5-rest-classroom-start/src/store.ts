import fs from 'node:fs/promises'
import path from 'node:path'


type Whisper = {
  id: number;
  message: string;
};

const filename = path.join(process.cwd(), 'db.json')

const saveChanges = async (data: Whisper[]): Promise<void> => {
  await fs.writeFile(filename, JSON.stringify(data))
}

const readData = async (): Promise<Whisper[]> => {

  const text = await fs.readFile(filename, "utf-8");
  const parsed: unknown = JSON.parse(text);

  if (!Array.isArray(parsed)) return [];

  return parsed
    .filter((currentWhisper): currentWhisper is Record<string, unknown> => 
      typeof currentWhisper === "object" && currentWhisper !== null)
    .map((currentWhisper) => ({
      id: typeof currentWhisper.id === "number" ? 
        currentWhisper.id : Number(currentWhisper.id),
      message: typeof currentWhisper.message === "string" ? 
        currentWhisper.message : String(currentWhisper.message ?? ""),
    }))
    .filter((currentWhisper) => Number.isFinite(currentWhisper.id));
};


const getAll = (): Promise<Whisper[]> => readData()

const getById = async (id: number) : Promise<Whisper | undefined> => {
  const data = await readData()
  return data.find((item: Whisper) => item.id === id)
}

const create = async (message: string) => {
  const data = await readData()
  const newItem: Whisper = { message, id: data.length + 1 }
  await saveChanges(data.concat([newItem]))
  return newItem
}

const updateById = async (id: number, message: string) => {
  const data = await readData()
  const newData = data.map((current: Whisper) => current.id === id
    ? { ...current, message }
    : current)
  await saveChanges(newData)
}

const deleteById = async (id: number) => {
  const data = await readData()
  const newData = data.filter((item: Whisper) => item.id !== id)
  await saveChanges(newData)
}

export {
  getAll,
  getById,
  create,
  updateById,
  deleteById
}
